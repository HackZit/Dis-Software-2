const sql = require('mssql');

module.exports = async function (context, req) {
  context.log('JavaScript HTTP trigger function processed a request.');

  const { ID } = req.body;

  const config = {
    user: 'admindis2',
    password: 'Dis123456',
    server: 'paymentsisserver.database.windows.net',
    database: 'PaymentSys',
    options: {
      encrypt: true,
      trustServerCertificate: true
    }
  };

  try {
    await sql.connect(config);

        const query1 = `
      SELECT id AS value, CAST(nro_tarjeta AS VARCHAR(50)) AS label
      FROM Tarjetas
      WHERE identificacion = '${ID}';
    `;

    const query2 = `
      SELECT id_ahorros AS value, banco AS label
      FROM tarjeta_debito
      WHERE identificacion = '${ID}';
    `;

    const result1 = await sql.query(query1);
    const result2 = await sql.query(query2);

    const jsonData = {
      Credito: {
        title: 'Credito',
        data: result1.recordset
      },
      Debito: {
        title: 'Debito',
        data: result2.recordset
      }
    };

      context.res = {
        status: 200,
        body: jsonData
      };
  } catch (error) {
    context.log('Error:', error);
    context.res = {
      status: 500,
      body: 'An error occurred while querying the database'
    };
  } finally {
    await sql.close();
  }
};
