const sql = require('mssql');


module.exports = async function (context, req) {
  context.log('JavaScript HTTP trigger function processed a request.');
  // Retrieve the JSON data from the request body
  const { name, email, ID} = req.body;

  // Configure the SQL database connection
  const config = {
    user: 'admindis2',
    password: 'Dis123456',
    server: 'paymentsisserver.database.windows.net',
    database: 'PaymentSys',
    options: {
      encrypt: true, // If using Azure SQL Database, set to true
      trustServerCertificate: true // If using Azure SQL Database, set to true
    }
  };

  context.log('Path found');

  try {
    context.log('PRE CONNECTED');
    // Connect to the SQL database using the connection string
    await sql.connect(config);
    context.log('CONNECTED');

    // Prepare the SQL query
    const query = `SELECT * FROM Usuarios WHERE identificacion = '${ID}' AND nombre_completo = '${name}' AND email = '${email}';`;
    context.log('PRE QUERYED');

    // Execute the SQL query
    const result = await sql.query(query);
    context.log('POST QUERYED');

    // Handle the query result
    if (result.recordset.length > 0) {
      const record = result.recordset[0];
      // Do something with the record (e.g., return it as the response)
      context.res = {
        body: record
      };
    } else {
      // No record found with the specified ID
      context.res = {
        status: 202,
        body: {
          identificacion: 0,
          nombre_completo: "notfound",
          email: "notfound"
        }
      };
    }
  } catch (error) {
    // Handle any errors that occurred during the database operation
    context.log('ERROR ' + error);

    context.res = {
      status: 500,
      body: 'An error occurred while querying the database'
    };
  } finally {
    // Close the database connection
    await sql.close();
  }
};
