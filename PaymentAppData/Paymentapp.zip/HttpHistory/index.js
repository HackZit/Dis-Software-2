const sql = require('mssql');

module.exports = async function (context, req) {
  context.log('JavaScript HTTP trigger function processed a request.');

  const { ID } = req.body;

  const config = {
    user: 'admindis2',
    password: 'Dis123456',
    server: 'paymentsisserver.database.windows.net',
    database: 'PaymentSys',
    options: {
      encrypt: true,
      trustServerCertificate: true
    }
  };

  try {
    await sql.connect(config);

    const query = `SELECT *
                    FROM Facturas
                    WHERE identificacion = '${ID}'`;

    const result = await sql.query(query);

    if (result.recordset.length > 0) {
      const records = result.recordset;
      context.res = {
        status: 200,
        body: records
      };
    } else {
      context.res = {
        status: 200,
        body: []
      };
    }
  } catch (error) {
    context.log('Error:', error);
    context.res = {
      status: 500,
      body: 'An error occurred while querying the database'
    };
  } finally {
    await sql.close();
  }
};
