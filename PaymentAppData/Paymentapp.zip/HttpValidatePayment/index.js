const sql = require('mssql');

module.exports = async function (context, req) {
  context.log('JavaScript HTTP trigger function processed a request.');

  // Retrieve the JSON data from the request body
  const {
    identificacion,
    hora,
    fecha,
    metodo_pago,
    id,
    cuotas,
    estado,
    sede,
    razon,
    amount
  } = req.body;

  // Configure the SQL database connection
  const config = {
    user: 'admindis2',
    password: 'Dis123456',
    server: 'paymentsisserver.database.windows.net',
    database: 'PaymentSys',
    options: {
      encrypt: true, // If using Azure SQL Database, set to true
      trustServerCertificate: true // If using Azure SQL Database, set to true
    }
  };
  context.log('Config ready');

  try {
    // Connect to the SQL database using the connection string
    await sql.connect(config);
    context.log('Connected!');
    var query = ``;
    if (metodo_pago == "Credito"){
        query = `
        SELECT id
        FROM Tarjetas
        WHERE saldo >= ${amount}
            AND estadotar = 1
            AND id = ${id};
        `;
    } else {
        query = `
        SELECT id_ahorros
        FROM tarjeta_debito
        WHERE saldo >= ${amount}
            AND estado = 1
            AND id_ahorros = ${id};
        `;
    }
    // Create a SQL query to verify the conditions


    // Execute the SQL query
    const result = await sql.query(query);

    // Handle the query result
    if (result.recordset.length > 0) {
        var acceptedTarjetas;
        if (metodo_pago == "Credito"){
            acceptedTarjetas = result.recordset.map((row) => row.id);
        } else {
            acceptedTarjetas = result.recordset.map((row) => row.id_ahorros);
        }
      // Tarjetas that meet the conditions

      // Return the IDs of the accepted tarjetas as the response
      context.res = {
        body: {
          reply: 'Aprobado'
        }
      };
    } else {
      // No tarjetas found that meet the conditions
          context.log('No tarjetas found that meet the conditions!');
          
      // Create a new row in the Facturas table
      const facturaQuery = `
        INSERT INTO Facturas (identificacion, hora, fecha, metodo_pago, id, cuotas, estado, sede, razon, amount)
        VALUES ('${identificacion}', '${hora}', '${fecha}', '${metodo_pago}', ${id}, ${cuotas}, 0, '${sede}', '${razon}', ${amount});
      `;

      // Execute the facturaQuery
      await sql.query(facturaQuery);

          // Query the newly inserted row in Facturas table
    const selectQuery = `SELECT *
                            FROM Facturas
                            WHERE identificacion = '${identificacion}' AND hora = '${hora}' AND fecha = '${fecha}' AND metodo_pago = '${metodo_pago}' AND id = '${id}' AND cuotas = '${cuotas}' AND estado = 0 AND sede = '${sede}' AND razon = '${razon}' AND amount = ${amount};`;
    const result = await sql.query(selectQuery);

        const record = result.recordset[0];
        context.res = {
        status: 200,
        body: record
        };
    }
  } catch (error) {
    // Handle any errors that occurred during the database operation
    context.log.error('Error:', error);

    context.res = {
      status: 500,
      body: {
          reply: 'An error occurred while querying the database'
        }
    };
  } finally {
    // Close the database connection
    await sql.close();
  }
};
