const sql = require('mssql');

module.exports = async function (context, req) {
  context.log('JavaScript HTTP trigger function processed a request.');

  // Retrieve the ID from the request body or query parameters
  const id = req.body && req.body.ID ? req.body.ID : req.query && req.query.ID ? req.query.ID : null;

  // Check if ID is provided
  if (!id) {
    context.res = {
      status: 400, // Bad Request
      body: { message: 'Missing ID parameter' }
    };
    return;
  }

  // Configure the SQL database connection
  const config = {
    user: 'admindis2',
    password: 'Dis123456',
    server: 'paymentsisserver.database.windows.net',
    database: 'PaymentSys',
    options: {
      encrypt: true, // If using Azure SQL Database, set to true
      trustServerCertificate: true // If using Azure SQL Database, set to true
    }
  };

  try {
    // Connect to the SQL database using the connection string
    await sql.connect(config);

    // Prepare the SQL query
    const query = `
    SELECT CONVERT(VARCHAR, nro_tarjeta) AS nro_tarjeta, saldo, 'Credito' AS tipo
    FROM Tarjetas
    WHERE identificacion = '${id}'

    UNION

    SELECT banco, saldo, 'Debito' AS tipo
    FROM tarjeta_debito
    WHERE identificacion = '${id}';
    `;

    // Execute the SQL query
    const result = await sql.query(query);

    // Handle the query result
    if (result.recordset.length > 0) {
      // Extract the required columns from the result
      const data = result.recordset.map(record => ({
        account: record.nro_tarjeta,
        saldo: record.saldo,
        tipo: record.tipo
      }));

      // Return the data as JSON response
      context.res = {
        status: 200, // OK
        body: data
      };
    } else {
      // No records found with the specified ID
      context.res = {
        status: 200, // OK
        body: []
      };
    }
  } catch (error) {
    // Handle any errors that occurred during the database operation
    context.log('ERROR ' + error);

    context.res = {
      status: 500, // Internal Server Error
      body: { message: 'An error occurred while querying the database' }
    };
  } finally {
    // Close the database connection
    await sql.close();
  }
};
