const sql = require('mssql');

module.exports = async function (context, req) {
  context.log('JavaScript HTTP trigger function processed a request.');

  const {
    identificacion,
    hora,
    fecha,
    metodo_pago,
    id,
    cuotas,
    estado,
    sede,
    razon,
    amount
  } = req.body;

  const config = {
    user: 'admindis2',
    password: 'Dis123456',
    server: 'paymentsisserver.database.windows.net',
    database: 'PaymentSys',
    options: {
      encrypt: true,
      trustServerCertificate: true
    }
  };

  try {
    await sql.connect(config);
    var updateQuery;
    if (metodo_pago == "Credito"){
        updateQuery = `UPDATE Tarjetas
                         SET saldo = saldo - ${amount}
                         WHERE id = '${id}';`;
    } else {
        updateQuery = `UPDATE tarjeta_debito
                         SET saldo = saldo - ${amount}
                         WHERE id_ahorros = '${id}';`;
    }
    // Update saldo in Tarjetas table
    await sql.query(updateQuery);

    // Insert new row in Facturas table
    const insertQuery = `INSERT INTO Facturas (identificacion, hora, fecha, metodo_pago, id, cuotas, estado, sede, razon, amount)
                         VALUES ('${identificacion}', '${hora}', '${fecha}', '${metodo_pago}', '${id}', '${cuotas}', 1, '${sede}', '${razon}', ${amount});`;
    await sql.query(insertQuery);

    // Query the newly inserted row in Facturas table
    const selectQuery = `SELECT *
                         FROM Facturas
                         WHERE identificacion = '${identificacion}' AND hora = '${hora}' AND fecha = '${fecha}' AND metodo_pago = '${metodo_pago}' AND id = '${id}' AND cuotas = '${cuotas}' AND estado = 1 AND sede = '${sede}' AND razon = '${razon}' AND amount = ${amount};`;
    const result = await sql.query(selectQuery);

    if (result.recordset.length > 0) {
      const record = result.recordset[0];
      context.res = {
        status: 200,
        body: record
      };
    } else {
      context.res = {
        status: 404,
        body: {
          reply: 'Matching row not found in Facturas table'
        }
      };
    }
  } catch (error) {
    context.log('Error:', error);
    context.res = {
      status: 500,
      body: {
        reply: 'An error occurred while updating the database'
      }
    };
  } finally {
    await sql.close();
  }
};
